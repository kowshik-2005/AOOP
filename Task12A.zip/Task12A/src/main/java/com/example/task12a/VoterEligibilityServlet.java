package com.example.task12a;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

@WebServlet("/VoterEligibilityServlet")  // URL mapping
public class VoterEligibilityServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set the content type of the response to HTML
        response.setContentType("text/html");

        // Get the writer to output HTML content
        PrintWriter out = response.getWriter();

        // Retrieve name and age parameters from the form
        String name = request.getParameter("name");
        String ageStr = request.getParameter("age");

        // Check if name and age are provided
        if (name == null || name.isEmpty() || ageStr == null || ageStr.isEmpty()) {
            out.println("<h3>Error: Please enter both name and age.</h3>");
        } else {
            try {
                // Parse age to an integer
                int age = Integer.parseInt(ageStr);

                // Check voting eligibility
                if (age >= 18) {
                    out.println("<h2>Hello " + name + ", you are eligible to vote!</h2>");
                } else {
                    out.println("<h2>Hello " + name + ", you are not eligible to vote yet.</h2>");
                }

            } catch (NumberFormatException e) {
                // Handle non-numeric age input
                out.println("<h3>Error: Age must be a valid number.</h3>");
            }
        }
        
        // Close the writer
        out.close();
    }
}
