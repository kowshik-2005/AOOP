package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/student")
public class StudentDetailsServlet extends HttpServlet {
    private static final String URL = "jdbc:postgresql://localhost:5432/studentDB";
    private static final String USER = "postgres";
    private static final String PASSWORD = "123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String program = request.getParameter("program");

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "INSERT INTO Registration (id, name, address, program) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(id));
            pstmt.setString(2, name);
            pstmt.setString(3, address);
            pstmt.setString(4, program);
            pstmt.executeUpdate();
            response.getWriter().println("Student details saved successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error saving student details.");
        }
    }
}
