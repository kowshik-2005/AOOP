package com.example;

import java.sql.*;

public class UpdateRecords {
    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/studentDB", "postgres", "123")) {
            String query = "UPDATE Registration SET program = ? WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);

            pstmt.setString(1, "Data Science");
            pstmt.setInt(2, 100);
            pstmt.executeUpdate();

            pstmt.setString(1, "Data Science");
            pstmt.setInt(2, 101);
            pstmt.executeUpdate();

            System.out.println("Records updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
