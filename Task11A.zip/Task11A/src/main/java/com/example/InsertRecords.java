package com.example;

import java.sql.*;

public class InsertRecords {
    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/studentDB", "postgres", "123")) {
            String query = "INSERT INTO Registration (id, name, address, program) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);

            pstmt.setInt(1, 100);
            pstmt.setString(2, "John Doe");
            pstmt.setString(3, "123 Main St");
            pstmt.setString(4, "Computer Science");
            pstmt.executeUpdate();

            pstmt.setInt(1, 101);
            pstmt.setString(2, "Jane Smith");
            pstmt.setString(3, "456 Oak Ave");
            pstmt.setString(4, "Mathematics");
            pstmt.executeUpdate();

            pstmt.setInt(1, 102);
            pstmt.setString(2, "Mike Brown");
            pstmt.setString(3, "789 Pine Rd");
            pstmt.setString(4, "Physics");
            pstmt.executeUpdate();

            pstmt.setInt(1, 103);
            pstmt.setString(2, "Sara White");
            pstmt.setString(3, "321 Elm St");
            pstmt.setString(4, "Biology");
            pstmt.executeUpdate();

            System.out.println("Records inserted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
