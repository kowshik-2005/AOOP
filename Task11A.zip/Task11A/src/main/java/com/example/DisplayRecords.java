package com.example;

import java.sql.*;

public class DisplayRecords {
    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/studentDB", "postgres", "123")) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Registration");

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name") +
                                   ", Address: " + rs.getString("address") + ", Program: " + rs.getString("program"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
