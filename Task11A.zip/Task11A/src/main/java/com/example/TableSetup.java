package com.example;

import java.sql.*;

public class TableSetup {
	public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/studentDB", "postgres", "123")) {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("CREATE TABLE Registration (id SERIAL PRIMARY KEY, name VARCHAR(100), address VARCHAR(255), program VARCHAR(100))");
            System.out.println("Table created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
