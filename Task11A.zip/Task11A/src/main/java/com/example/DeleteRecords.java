package com.example;

import java.sql.*;

public class DeleteRecords {
    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/studentDB", "postgres", "123")) {
            String query = "DELETE FROM Registration WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);

            pstmt.setInt(1, 101);
            pstmt.executeUpdate();

            System.out.println("Record deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
