package com.example;
import java.sql.*;

public class DatabaseSetup {
	 public static void main(String[] args) {
	        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "123")) {
	            Statement stmt = conn.createStatement();
	            stmt.executeUpdate("CREATE DATABASE studentDB");
	            System.out.println("Database created successfully.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

}
